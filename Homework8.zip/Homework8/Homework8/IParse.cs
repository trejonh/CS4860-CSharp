﻿namespace Homework8
{
    public interface IParse<T>
    {
        T Parse(byte[] buffer);
    }
}
