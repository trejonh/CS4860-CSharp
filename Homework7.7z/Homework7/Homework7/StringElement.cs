﻿namespace Homework7
{
    class StringElement : ParseElement
    {
        public new string Parse(byte[] buffer)
        {
            return base.Parse(buffer);
        }
    }
}
