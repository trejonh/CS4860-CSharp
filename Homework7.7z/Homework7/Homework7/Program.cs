﻿namespace Homework7
{
    class Program
    {
        public static void Main()
        {
            
        }
    }
}
