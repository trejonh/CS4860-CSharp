﻿
using System;

namespace Homework0
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Hello, World");
        }
    }
}
